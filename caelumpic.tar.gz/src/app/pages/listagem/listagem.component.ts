import { Component } from '@angular/core';
import { FotoService } from '../../shared/foto/foto.service';
import { FlashMessageService } from '../../utils/flashMessage.service';

@Component({
  templateUrl: './listagem.component.html'
})
export class ListagemComponent {
  title = 'Caelumpic';
  fotos=[];
  service:FotoService;
  mensagem='';
  flashMessage:FlashMessageService;

  constructor(service:FotoService,flashMessage:FlashMessageService){
    this.service = service;
    this.mensagem = flashMessage.get("cadastro");
    this.service.listar()
    .subscribe(fotos=>{
      this.fotos=fotos;
      console.log(this.fotos);

    });
  }

  remover(foto){
    this.service.remove(foto)
    .subscribe(()=>{
      console.log("Foto Removida");
      this.fotos=this.fotos.filter(f=>f._id!=foto._id);
      this.mensagem="Foto removida com sucesso";
    },
    ()=>this.mensagem="Não foi possível remover"
  );
  }
}
