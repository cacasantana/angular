import {NgModule} from '@angular/core';
import { FlashMessageService } from './flashMessage.service';

@NgModule({
    providers:[FlashMessageService]
})
export class UtilsModule{

}