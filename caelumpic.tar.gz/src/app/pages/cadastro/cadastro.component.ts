import { Component } from "@angular/core";
import { FotoComponent } from '../../shared/foto/foto.component'
import { FotoService } from "../../shared/foto/foto.service";
import { ActivatedRoute, Router } from '@angular/router';
import { FlashMessageService } from '../../utils/flashMessage.service';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
    templateUrl:'./cadastro.component.html'
})
export class CadastroComponent{
    foto = new FotoComponent();
    service:FotoService;
    mensagem='';
    router:Router;
    flashMessage:FlashMessageService;
    meuForm:FormGroup;
    
    constructor(
            service:FotoService,
            activedRoute:ActivatedRoute,
            router:Router,
            flashMessage:FlashMessageService,
            fb:FormBuilder
        ){

        this.service=service;
        this.router=router;
        this.flashMessage=flashMessage;

        activedRoute.params.subscribe(({id})=>{//object destructuring
            if(id){
                this.service.buscaPorId(id).subscribe(foto=>this.foto=foto);
            }
        });

        this.meuForm=fb.group({
            titulo:["",Validators.compose([
                Validators.required,
                Validators.minLength(3)
            ])],
            url:["",Validators.required],
            descricao:["",Validators.required]
        });
    }
    salvar(){
        if(this.foto._id){
            this.service.atualiza(this.foto)
            .subscribe(()=>{
                this.mensagem=" atualizada com sucesso";
                this.flashMessage.add("cadastro",this.foto.titulo+this.mensagem)
                this.router.navigate([""]);
            })
        }else{
            console.log(this.foto);
            this.service.salva(this.foto)
            .subscribe(()=>{
                this.meuForm.reset();
                this.mensagem=" Foto incluída com sucesso";
                this.flashMessage.add("cadastro",this.mensagem)
                this.router.navigate([""]);
            })
        }
    }
}