import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';//todo cara que eu crio tem que ter esse
import { SharedModule} from '../../shared/shared.module'
import { CadastroComponent} from './cadastro.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { UtilsModule } from '../../utils/utils.module';
import { cadastroRoutingModule } from './cadastro.routing.module';

@NgModule({
    declarations:[ CadastroComponent ],
    imports: [
        CommonModule,
        SharedModule,
        FormsModule,
        UtilsModule,
        ReactiveFormsModule,
        cadastroRoutingModule
    ]
})
export class CadastroModule{

}